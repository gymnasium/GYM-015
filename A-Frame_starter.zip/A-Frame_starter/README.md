[![Gymnasium Logo](https://gymnasium.github.io/cms/img/gymnasium-logo-gray.svg)](http://thegymnasium.com)

# Introduction to WebXR

**A free online course at the [Gymnasium](http://thegymnasium.com)**

---

### GYM-015 Starter Files


This demo is built on top of the repo from the gulp starter [CSS Tricks tutorial](https://css-tricks.com/gulp-for-beginners/). 


Check if you have node installed: `node -v`

Check if you have npm installed: `npm -v`

If not, install from [nodejs.org](https://nodejs.org/)


Run `npm install` command after cloning this repo. 

Run `npm install -g gulp` (you might have to use `sudo npm install -g gulp` )

--

Start the server `gulp`

Stop the server `ctrl + c`