var gulp = require('gulp');
var browserSync = require('browser-sync').create();

// Development Tasks 
// -----------------

// Static server
gulp.task('browser-sync', function() {
    browserSync.init({
        server: {
            baseDir: "app"
        }
    });
});

// Watchers
gulp.task('watch', function() {
  gulp.watch('app/scss/**/*.scss', ['sass']);
  gulp.watch('app/*.html', browserSync.reload);
  gulp.watch('app/js/**/*.js', browserSync.reload);
})


// Default Task
gulp.task('default', ['browser-sync', 'watch']);
